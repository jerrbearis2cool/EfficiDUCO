import socket, random, hashlib, ast, requests
from json_stuff import json_put, json_get
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind(("127.0.0.1", 3334))
s.listen(5)
print("node started")
while True:
    ipgreylist = json_get("./ip_grey_list.json")
    try:
        clientsocket, address = s.accept()
        print(f"Connection from {address} has been established.")
        msg = clientsocket.recv(1024).decode("utf-8")
        if "GET_PAY" in msg:
            print(msg)
            msg = msg.replace("GET_PAY", "")
            msg = ast.literal_eval(msg)
            payaddress = msg.get("ACCOUNT")
            amount = msg.get("AMOUNT")
            time = msg.get("TIME")
            print(msg)
            if int(amount) > 8:
                clientsocket.send(bytes("GET_PAY" + "TOO_MUCH", "utf-8"))
            elif int(time) < 0:
                clientsocket.send(bytes("GET_PAY" + "NOT_ENOUGH_TIME", "utf-8"))
            elif address in ipgreylist:
                clientsocket.send(bytes("GET_PAY" + "GREY_LISTED", "utf-8"))
            else:
                print(requests.get("https://server.duinocoin.com/transaction?username=jerrbearisawsome&password=DOG12345&recipient=" + payaddress + "&amount=" + str(amount) + "&memo=efficentDUCO payout"))
                clientsocket.send(bytes("GET_PAY" + "success", "utf-8"))
                print("payed")
                ipgreylist.append(address)
                json_put(ipgreylist, "./ip_grey_list.json", False)
    except ConnectionResetError:
        pass