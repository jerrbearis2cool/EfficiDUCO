import subprocess
subprocess.call([r"start.bat"])