from json_stuff import json_put, json_get
import datetime
#code is near stolen, just for the security of my balance
while True:
    tm = datetime.datetime.now()
    now_time = tm.time()

    starthr = 23
    startmin = 55
    stophr = 0
    stopmin = 3

    if stophr >= starthr:
        if now_time >= datetime.time(starthr, startmin) and now_time <= datetime.time(stophr, stopmin):
            print("in the range")
            json_put([], "./ip_grey_list.json", False)
    else:
        if now_time <= datetime.time(stophr, stopmin) or now_time >= datetime.time(starthr, startmin):
            print("in the range")
            json_put([], "./ip_grey_list.json", False)
        else:
            print("not in the range")